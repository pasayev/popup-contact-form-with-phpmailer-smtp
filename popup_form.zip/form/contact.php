<?php session_start(); ?>

<!doctype html>
<html lang="tr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
        <!-- Optional theme -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" >
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="form.css" >
        <script src="form.js"></script>
  </head>
  <body>
	  
	  
	  
<div class="container">
            <div class="container-box">
				<div data-toggle="modal" data-target="#myModal" style="text-align: center; margin-left:auto; margin-right: auto;margin-top:30px;margin-bottom:30px;"><a href="#myModal"><img src="https://badufurniture.com/teklif_iste.png" /></a></div>
               
				
				
            </div>
            <!-- Modal -->
            <div id="myModal" class="modal fade" role="dialog">
                <div class="modal-dialog">
                    <!-- Modal content-->
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                            <h4 class="modal-title">
                                Teklif Formu
                            </h4>
                        </div>
                        <div class="modal-body">
                            <div class="card-body">

                <form action="sendmail.php" method="POST">

                    <div class="form-group">
                        <label for="fullname">Adınız Soyadınız</label>
                        <input type="text" name="full_name" id="fullname" required class="form-control" />
                    </div>
                    <div class="form-group">
                        <label for="email_address">E-posta</label>
                        <input type="email" name="email" id="email_address" required class="form-control" />
                    </div>
                    <div class="form-group">
                        <label for="subject">Telefon</label>
                        <input type="text" name="subject" id="subject" required class="form-control" />
                    </div>
                    <div class="form-group">
                        <label for="message">Mesajınız</label>
                        <textarea name="message" id="message" required class="form-control" rows="3"></textarea>
                    </div>
                    <div class="form-group">
                       
						
						  <button type="submit" name="submitContact" class="btn btn-lg btn-success btn-block">Gönder &rarr;</button>
                    </div>

                </form>

            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

    <script src="sweetalert2@11.js"></script>
    <script>

        var messageText = "<?= $_SESSION['status'] ?? '';  ?>";
        if(messageText != ''){
            Swal.fire({
                title: "Teklifiniz İletildi.<br> Teşekkür Ederiz.",
                text: messageText,
                icon: "success"
            });
            <?php unset($_SESSION['status']); ?>
        }

    </script>
                        </div>
                    </div>
                </div>
            </div>
        </div>

  </body>
</html>